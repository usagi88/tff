import React from 'react'
import TFFPortal from './components/TFFPortal'

export default function App() {
  return <TFFPortal />
}
